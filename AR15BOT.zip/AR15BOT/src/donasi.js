const donasi = () => {
	return `*👾DIL-BOT 👾*

  Hi👋️
  
          *FITUR*
          
┏━━━°❀ ❬ *ABOUT* ❭ ❀°━━━┓
┃
┏❉ *#info*
┣❉ *#Donasi* 
┗❉ *#creator* 
┃
┣━━━°❀ ❬ *DONASI* ❭ ❀°━━━⊱
┃
┣➥ *GOPAY:* 0857-2255-3839
┣➥ *PULSA:* 0857-2255-3839
┣➥ *OVO:* 0857-2255-3839
┃
┣━━━━━━━━━━━━━━━━━━━━
┃
┃
┃
┣━━━━━━━━━━━━━━━━━━━━
┃ *POWERED BY DIL-BOT ID*
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.donasi = donasi
